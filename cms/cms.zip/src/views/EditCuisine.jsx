import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import axios from "axios";
import { baseUrl } from "../api/baseUrl";

export default function EditCuisine() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [dataCuisine, setDataCuisine] = useState({});
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState(0);
  const [imgUrl, setImgUrl] = useState("");
  const [stock, setStock] = useState(0);
  const [categoryId, setCategoryId] = useState(0);

  const fetchCuisine = async () => {
    try {
      const { data } = await axios.get(`${baseUrl}/apis/restaurant-app/cuisines/${id}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("access_token")}`,
        },
      });
      console.log(data);

      setDataCuisine(data.data);
      setName(data.data.name);
      setDescription(data.data.description);
      setPrice(data.data.price);
      setImgUrl(data.data.imgUrl);
      setStock(data.data.stock);
      setCategoryId(data.data.categoryId);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchCuisine();
  }, []); // Only run once when component mounts

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const body = {
        name,
        description,
        price: +price,
        imgUrl,
        stock: +stock,
        categoryId: +categoryId,
      };

      await axios.put(`${baseUrl}/apis/restaurant-app/cuisines/${id}`, body, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("access_token")}`,
        },
      });
      navigate("/");
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="container py-4">
      <div className="row justify-content-center">
        <div className="col-md-8">
          <div className="card shadow-sm">
            <div className="card-body p-4">
              <div className="d-flex justify-content-between align-items-center mb-4">
                <h3 className="mb-0">Edit Cuisine</h3>
                <button onClick={() => navigate("/")} className="btn btn-outline-secondary">
                  <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>
                    close
                  </span>
                </button>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label className="form-label">Name</label>
                  <input type="text" className="form-control" value={name} onChange={(e) => setName(e.target.value)} required />
                </div>

                <div className="mb-3">
                  <label className="form-label">Category</label>
                  <select className="form-select" value={categoryId} onChange={(e) => setCategoryId(e.target.value)} required>
                    <option value="">Select category</option>
                    <option value="1">Main Course</option>
                    <option value="2">Appetizer</option>
                    <option value="3">Dessert</option>
                    <option value="4">Beverage</option>
                  </select>
                </div>

                <div className="mb-3">
                  <label className="form-label">Price</label>
                  <div className="input-group">
                    <span className="input-group-text">Rp</span>
                    <input type="number" className="form-control" value={price} onChange={(e) => setPrice(e.target.value)} required />
                  </div>
                </div>

                <div className="mb-4">
                  <label className="form-label">Description</label>
                  <textarea className="form-control" rows="3" value={description} onChange={(e) => setDescription(e.target.value)}></textarea>
                </div>

                <div className="d-grid">
                  <button type="submit" className="btn btn-primary">
                    <span className="material-symbols-outlined me-1" style={{ fontSize: "20px", verticalAlign: "middle" }}>
                      save
                    </span>
                    Update Cuisine
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
