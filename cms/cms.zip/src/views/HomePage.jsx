import { useState, useEffect } from "react";
import { Link } from "react-router";
import axios from "axios";
import Table from "../components/Table";
import { baseUrl } from "../api/baseUrl";

export default function HomePage() {
  // Hardcoded data for now
  const [cuisines, setCuisines] = useState([]);
  const [loading, setLoading] = useState(true);

  async function fetchCuisines() {
    try {
      setLoading(true);
      const { data } = await axios.get(`${baseUrl}/apis/restaurant-app/cuisines`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("access_token")}`,
        },
      });
      console.log(data, "<<<<<<<<<<<<<<<<<<<<<<, ini di fetch data");
      if (data?.data) {
        setCuisines(data.data);
      } else {
        setCuisines([]);
        console.log("No data available or invalid format");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      setCuisines([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchCuisines();
  }, []);

  const getSpicyIcon = (level) => {
    switch (level.toLowerCase()) {
      case "high":
        return <span className="material-symbols-outlined text-danger">local_fire_department local_fire_department local_fire_department</span>;
      case "medium":
        return <span className="material-symbols-outlined text-warning">local_fire_department local_fire_department</span>;
      case "mild":
        return <span className="material-symbols-outlined text-success">local_fire_department</span>;
      default:
        return <span className="text-muted">-</span>;
    }
  };

  if (loading) {
    return (
      <div className="container py-4 text-center">
        <div className="spinner-border text-danger" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div className="d-flex align-items-center">
          <span className="material-symbols-outlined me-2 text-danger" style={{ fontSize: "32px" }}>
            restaurant
          </span>
          <h2 className="mb-0">Spicy Cuisines</h2>
        </div>
        <Link to="/cuisines/add" className="btn btn-danger">
          <span className="material-symbols-outlined me-1" style={{ fontSize: "20px", verticalAlign: "middle" }}>
            add
          </span>
          Add Cuisine
        </Link>
      </div>

      <Table
        cuisines={cuisines}
        columns={[
          {
            name: "Name",
            selector: (row) => row.name,
            sortable: true,
          },
          {
            name: "Category",
            selector: (row) => row.category,
            sortable: true,
          },
          {
            name: "Price",
            selector: (row) => `Rp ${row.price.toLocaleString()}`,
            sortable: true,
          },
          {
            name: "Spicy Level",
            selector: (row) => getSpicyIcon(row.spicyLevel),
            sortable: false,
          },
          {
            name: "Actions",
            selector: (row) => (
              <div className="btn-group">
                <Link to={`/cuisines/${row.id}`} className="btn btn-sm btn-outline-secondary">
                  <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>
                    visibility
                  </span>
                </Link>
                <Link to={`/cuisines/${row.id}/edit`} className="btn btn-sm btn-outline-primary">
                  <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>
                    edit
                  </span>
                </Link>
                <Link to={`/cuisines/${row.id}/upload`} className="btn btn-sm btn-outline-danger">
                  <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>
                    upload
                  </span>
                </Link>
              </div>
            ),
            sortable: false,
          },
        ]}
      />
    </div>
  );
}
