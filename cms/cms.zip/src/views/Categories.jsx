import { useState } from "react";

export default function Categories() {
  const [categories] = useState([
    { id: 1, name: "Main Course", totalItems: 12 },
    { id: 2, name: "Appetizer", totalItems: 8 },
    { id: 3, name: "Dessert", totalItems: 6 },
    { id: 4, name: "Beverage", totalItems: 10 },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [newCategory, setNewCategory] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add create logic here later
    setShowAddModal(false);
    setNewCategory("");
  };

  return (
    <div className="container py-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="mb-0">Categories</h2>
        <button className="btn btn-primary" onClick={() => setShowAddModal(true)}>
          <span className="material-symbols-outlined me-1" style={{ fontSize: "20px", verticalAlign: "middle" }}>
            add
          </span>
          Add Category
        </button>
      </div>

      <div className="row">
        {categories.map((category) => (
          <div key={category.id} className="col-md-6 col-lg-4 mb-4">
            <div className="card shadow-sm h-100">
              <div className="card-body">
                <div className="d-flex justify-content-between align-items-center">
                  <h5 className="card-title mb-0">{category.name}</h5>
                  <button className="btn btn-sm btn-outline-danger">
                    <span className="material-symbols-outlined" style={{ fontSize: "18px" }}>
                      delete
                    </span>
                  </button>
                </div>
                <p className="text-muted mt-2 mb-0">{category.totalItems} items</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Category Modal */}
      {showAddModal && (
        <div className="modal show d-block" style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Add New Category</h5>
                <button type="button" className="btn-close" onClick={() => setShowAddModal(false)}></button>
              </div>
              <form onSubmit={handleSubmit}>
                <div className="modal-body">
                  <div className="mb-3">
                    <label className="form-label">Category Name</label>
                    <input type="text" className="form-control" value={newCategory} onChange={(e) => setNewCategory(e.target.value)} required />
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={() => setShowAddModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Save Category
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
