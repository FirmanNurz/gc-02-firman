import { useState } from "react";
import axios from "axios";
import { baseUrl } from "../api/baseUrl";
import { useNavigate } from "react-router";
import Toastify from "toastify-js";
import { useEffect } from "react";
import Button from "../components/Button";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.access_token) {
      Toastify({
        text: "You are already logged in",
        duration: 3000,
        newWindow: true,
        close: true,
        gravity: "top", // `top` or `bottom`
        position: "center", // `left`, `center` or `right`
        stopOnFocus: true, // Time in seconds to stop the toast
        style: {
          background: "linear-gradient(to right, #00b09b, #96c93d)",
          color: "white",
          border: "1px solid #96c93d",
          borderRadius: "2px",
          boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
        },
      }).showToast();
      navigate("/");
    }
  }, [navigate]);

  async function login(l) {
    l.preventDefault();
    try {
      const { data } = await axios.post(`${baseUrl}/apis/login`, {
        email: email,
        password: password,
      });
      localStorage.setItem("access_token", data?.data?.access_token);
      navigate("/");
      Toastify({
        text: "Login successful",
        duration: 3000,
        newWindow: true,
        close: true,
        gravity: "top", // `top` or `bottom`
        position: "center", // `left`, `center` or `right`
        stopOnFocus: true, // Time in seconds to stop the toast
        style: {
          background: "linear-gradient(to right, #00b09b, #96c93d)",
          color: "white",
          border: "1px solid #96c93d",
          borderRadius: "2px",
          boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
        },
      }).showToast();
    } catch (error) {
      Toastify({
        text: error?.response?.data?.error,
        duration: 3000,
        newWindow: true,
        close: true,
        gravity: "top", // `top` or `bottom`
        position: "center", // `left`, `center` or `right`
        stopOnFocus: true, // Time in seconds to stop the toast
        style: {
          background: "linear-gradient(to right, #00b09b, #96c93d)",
          color: "white",
          border: "1px solid #96c93d",
          borderRadius: "2px",
          boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
        },
      }).showToast();
    }
  }

  return (
    <div className="min-vh-100 d-flex align-items-center bg-light">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-6 col-lg-4">
            <div className="card shadow-sm">
              <div className="card-body p-4">
                <div className="text-center mb-4">
                  <h3 className="fw-bold">Welcome Back!</h3>
                  <p className="text-muted">Please login to continue</p>
                </div>
                <form onSubmit={login}>
                  <div className="mb-4">
                    <label className="form-label">Email address</label>
                    <input
                      type="email"
                      id="email"
                      className="form-control"
                      placeholder="Enter email"
                      autoComplete="current-email"
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                  <div className="mb-4">
                    <label className="form-label">Password</label>
                    <input
                      type="password"
                      id="password"
                      className="form-control"
                      placeholder="Enter password"
                      autoComplete="current-password"
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                  <button type="submit" className="btn btn-primary w-100 mb-3">
                    Login
                  </button>
                  <p className="text-center mb-0">
                    New staff member? <a href="/register">Register here</a>
                  </p>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
