import { useState } from "react";
import { useNavigate, useParams } from "react-router";

export default function UploadImage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [selectedFile, setSelectedFile] = useState(null);
  const [preview, setPreview] = useState(null);

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add upload logic here later
    navigate("/");
  };

  return (
    <div className="container py-4">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card shadow-sm">
            <div className="card-body p-4">
              <div className="d-flex justify-content-between align-items-center mb-4">
                <h3 className="mb-0">Upload Image</h3>
                <button onClick={() => navigate("/")} className="btn btn-outline-secondary">
                  <span className="material-symbols-outlined" style={{ fontSize: "20px" }}>
                    close
                  </span>
                </button>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <div className="d-flex justify-content-center mb-3">
                    {preview ? (
                      <img src={preview} alt="Preview" className="img-fluid rounded" style={{ maxHeight: "200px" }} />
                    ) : (
                      <div className="text-center p-5 bg-light rounded">
                        <span className="material-symbols-outlined" style={{ fontSize: "48px", color: "#6c757d" }}>
                          image
                        </span>
                        <p className="text-muted mt-2 mb-0">No image selected</p>
                      </div>
                    )}
                  </div>

                  <div className="input-group">
                    <input type="file" className="form-control" accept="image/*" onChange={handleFileSelect} required />
                  </div>
                </div>

                <div className="d-grid">
                  <button type="submit" className="btn btn-primary" disabled={!selectedFile}>
                    <span className="material-symbols-outlined me-1" style={{ fontSize: "20px", verticalAlign: "middle" }}>
                      upload
                    </span>
                    Upload Image
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
