export const baseUrl = "https://h8-phase2-gc.vercel.app";
